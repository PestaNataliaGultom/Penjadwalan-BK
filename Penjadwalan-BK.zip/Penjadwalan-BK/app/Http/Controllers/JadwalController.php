<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\User;

class JadwalController extends Controller
{
    public function index()
    {
        $guru = User::whereHas('roles', function($q){
            $q->where('name', 'Guru Bk');
        })->get();
        return view('guru.jadwal', compact('guru'));
    }
}
