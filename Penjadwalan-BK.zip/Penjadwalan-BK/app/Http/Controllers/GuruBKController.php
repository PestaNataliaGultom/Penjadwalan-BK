<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use App\Models\Schedule;

class GuruBKController extends Controller
{
    public function dashboard()
    {
        $totalSiswa = User::whereHas('roles', function($q){
            $q->where('name', 'Siswa');
        })->count();

        $konselingAktif = 0;
        $totalJadwalHariIni = Schedule::with('user')->whereDate('schedule_date', now()->format('Y-m-d'))->count();

        $today = Carbon::today();
        $totalGuruBK = User::whereHas('roles', function($q){
            $q->where('name', 'Guru Bk');
        })->count();

        $konselingTerbaru =Schedule::with('user')->orderBy('to_time')->get();

        $guru = User::whereHas('roles', function($q){
            $q->where('name', 'Guru Bk');
        })->get();

        $schedules = Schedule::with('user')->whereDate('schedule_date', now()->format('Y-m-d'))->get();

    return view('guru.dashboard', compact(
        'totalSiswa',
        'totalGuruBK',
        'konselingAktif',
        'konselingTerbaru',
        'totalJadwalHariIni',
        'guru',
        'schedules'
         
    ));
}
    
    public function profile()
    {
        // Ambil data profil dari database atau session
        $profil = [
            'nama' => 'Guru BK',
            'nip' => '198501012010011001',
            'email' => 'gurubk@sekolah.sch.id',
            'telepon' => '0812-3456-7890',
            'pendidikan' => 'S1 Bimbingan Konseling',
            'tahun_mulai' => '2010',
            'alamat' => 'Jl. Pendidikan No. 123, Bandung',
            'tempat_lahir' => 'Bandung',
            'tanggal_lahir' => '1985-01-01'
        ];
        
        return view('guru.guru-bk.profile', compact('profil'));
    }
    
    public function updateProfile(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'telepon' => 'required|string|max:20',
            'alamat' => 'required|string',
            'pendidikan' => 'required|string|max:255'
        ]);
        
        // Update profil ke database
        // User::where('id', Auth::id())->update($request->only(['nama', 'email', 'telepon', 'alamat', 'pendidikan']));
        
        return redirect()->route('guru.guru-bk.profile')->with('success', 'Profil berhasil diperbarui!');
    }
    

}