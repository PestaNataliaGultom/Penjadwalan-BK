<div id="sidebar-wrapper">
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>SIBEKAL</h2>
        </div>

        <div class="menu-item <?php echo e(request()->routeIs('guru.dashboard') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('guru.dashboard')); ?>" class="menu-link">
                <div class="menu-icon">📊</div>
                <span>Dashboard</span>
            </a>
        </div>

        <div class="menu-item <?php echo e(request()->routeIs('guru.jadwal*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('guru.jadwal')); ?>" class="menu-link">
                <div class="menu-icon">📅</div>
                <span>Jadwal Konseling</span>
            </a>
        </div>

        <div class="menu-item <?php echo e(request()->routeIs('guru.hasil-konseling*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('guru.hasil-konseling')); ?>" class="menu-link">
                <div class="menu-icon">📋</div>
                <span>Hasil Konseling</span>
            </a>
        </div>

        <div class="menu-item <?php echo e(request()->routeIs('guru.pengumuman*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('guru.pengumuman')); ?>" class="menu-link">
                <div class="menu-icon">📢</div>
                <span>Pengumuman</span>
            </a>
        </div>

        <div class="menu-item <?php echo e(request()->routeIs('guru.pengaturan*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('guru.pengaturan')); ?>" class="menu-link">
                <div class="menu-icon">⚙️</div>
                <span>Pengaturan</span>
            </a>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\ASUS\Downloads\ikm-app\Penjadwalan-BK\resources\views/guru/layouts/sidebar.blade.php ENDPATH**/ ?>