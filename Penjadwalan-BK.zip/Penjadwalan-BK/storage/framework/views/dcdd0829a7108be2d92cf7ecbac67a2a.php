

<?php $__env->startSection('title', 'Dashboard Admin'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="content-header">
        <h1>Dashboard <?php echo e(Auth::user()->roles->pluck('name')[0] ?? "-"); ?></h1>
    </div>
    <div class="row">
        <div class="col-md-3">
            <div class="card dashboard-card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="card-title">Total Siswa</h5>
                            <h2 class="mb-0"><?php echo e($totalSiswa); ?></h2>
                        </div>
                        <div class="card-icon bg-light text-primary rounded">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card dashboard-card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="card-title">Konseling Aktif</h5>
                            <h2 class="mb-0">24</h2>
                        </div>
                        <div class="card-icon bg-light text-success rounded">
                            <i class="fas fa-comments"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card dashboard-card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="card-title">Jadwal Hari Ini</h5>
                            <h2 class="mb-0">8</h2>
                        </div>
                        <div class="card-icon bg-light text-warning rounded">
                            <i class="fas fa-calendar-day"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card dashboard-card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="card-title">Guru BK</h5>
                            <h2 class="mb-0"><?php echo e($totalGuruBK); ?></h2>
                        </div>
                        <div class="card-icon bg-light text-info rounded">
                            <i class="fas fa-user-tie"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Content Area for each page -->
    <div class="mt-4">
            <h1>Selamat datang di Dashboard Admin</h1>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Downloads\ikm-app\Penjadwalan-BK\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>