


<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>

        <div class="w-full max-w-md mx-auto">
          <div class="text-center mb-4">
            <img src="<?php echo e(asset('assets/images/logos/logo.png')); ?>" alt="Logo" width="150">
          </div>
<?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>

<?php endif; ?>
<form method="POST" action="<?php echo e(route('authenticate')); ?>">
    <?php echo csrf_field(); ?>
    <h1 class="h3 mb-3 fw-bold text-dark text-center">Login</h1>
    <div class="form-floating">
      <input type="email" class="form-control mb-3" name="email" placeholder="Masukkan Email" required>
      <label for="floatingInput">Email</label>
    </div>
    <div class="form-floating">
      <input type="password" class="form-control mb-3" name="password" placeholder="Masukkan Password" required>
      <label for="floatingPassword">Password</label>
    </div>

    <button class="btn btn-primary w-100 py-2" type="submit">Login</button>
  </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.auth.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Downloads\ikm-app\Penjadwalan-BK\resources\views/login.blade.php ENDPATH**/ ?>