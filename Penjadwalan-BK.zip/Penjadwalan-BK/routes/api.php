<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthenticationController;

// Route::post('/login', [AuthenticationController::class, 'login']);

// Route::middleware('auth:api')->group(function () {
//     Route::get('/users', [AuthenticationController::class, 'getUser']);
//     Route::post('/logout', [AuthenticationController::class, 'logout']);
//     Route::post('/refresh', [AuthenticationController::class, 'refresh']);
// });
