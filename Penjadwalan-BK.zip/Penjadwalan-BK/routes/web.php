<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthenticationController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\SiswaController as StudentController;
use App\Http\Controllers\Admin\SiswaController;
use App\Http\Controllers\Admin\GuruController;
use App\Http\Controllers\GuruBKController;
use App\Http\Controllers\HasilKonselingController;
use App\Http\Controllers\KonselingController;
use App\Http\Controllers\JadwalController;
use App\Http\Controllers\LaporanController;
use App\Http\Controllers\PengumumanController;
use App\Http\Controllers\PengaturanController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Halaman login
        Route::get('/', [AuthenticationController::class, 'login'])->name('login');
        Route::post('/authenticate', [AuthenticationController::class, 'authenticate'])->name('authenticate');
        Route::post('/logout', [AuthenticationController::class, 'logout'])->name('logout');

// Semua route di bawah ini butuh autentikasi
        Route::middleware(['auth'])->group(function () {

    // Dashboard umum
        Route::prefix('admin')->group(function () {
        Route::get('/dashboard', [DashboardController::class, 'index'])->name('admin.dashboard');
        Route::resource('siswa', SiswaController::class);
        Route::resource('guru', GuruController::class);
    });
    Route::prefix('siswa')->group(function () {
        Route::get('/dashboard', [StudentController::class, 'dashboard'])->name('siswa.dashboard');
        Route::get('/jadwal', [StudentController::class, 'jadwal'])->name('siswa.jadwal');
        Route::post('/jadwal', [StudentController::class, 'jadwalPost'])->name('siswa.jadwalPost');
        Route::get('/jadwal/json', [StudentController::class, 'getSchedules'])->name('siswa.jadwal.json');
    });
    /*
    |--------------------------------------------------------------------------
    | Routes Khusus Guru BK
    |--------------------------------------------------------------------------
    */
        Route::prefix('guru')->group(function () {
        Route::get('/dashboard', [GuruBKController::class, 'dashboard'])->name('guru.dashboard');
        // Guru BK
        Route::get('/guru-bk', [GuruBKController::class, 'index'])->name('guru.guru-bk');
        Route::get('/guru-bk/profile', [GuruBKController::class, 'profile'])->name('guru.guru-bk.profile');
        Route::put('/guru-bk/profile', [GuruBKController::class, 'updateProfile'])->name('guru.guru-bk.update-profile');
        Route::get('/dashboard/guru', [DashboardController::class, 'dashboardGuru'])->middleware('auth')->name('dashboard.guru');


        // Hasil Konseling
        Route::get('/hasil-konseling', [HasilKonselingController::class, 'index'])->name('guru.hasil-konseling');
        Route::get('/hasil-konseling/create', [HasilKonselingController::class, 'create'])->name('guru.hasil-konseling.create');
        Route::post('/hasil-konseling', [HasilKonselingController::class, 'store'])->name('guru.hasil-konseling.store');
        Route::get('/hasil-konseling/{id}', [HasilKonselingController::class, 'show'])->name('guru.hasil-konseling.show');
        Route::get('/hasil-konseling/{id}/edit', [HasilKonselingController::class, 'edit'])->name('guru.hasil-konseling.edit');
        Route::put('/hasil-konseling/{id}', [HasilKonselingController::class, 'update'])->name('guru.hasil-konseling.update');
        Route::delete('/hasil-konseling/{id}', [HasilKonselingController::class, 'destroy'])->name('guru.hasil-konseling.destroy');


        // Konseling
        Route::get('/konseling', [KonselingController::class, 'index'])->name('guru.konseling');
        Route::get('/konseling/create', [KonselingController::class, 'create'])->name('guru.konseling.create');
        Route::post('/konseling', [KonselingController::class, 'store'])->name('guru.konseling.store');
        Route::get('/konseling/{id}', [KonselingController::class, 'show'])->name('guru.konseling.show');
        Route::put('/konseling/{id}/status', [KonselingController::class, 'updateStatus'])->name('guru.konseling.update-status');

        // Jadwal
        Route::get('/jadwal', [JadwalController::class, 'index'])->name('guru.jadwal');
        Route::get('/jadwal/create', [JadwalController::class, 'create'])->name('guru.jadwal.create');
        Route::post('/jadwal', [JadwalController::class, 'store'])->name('guru.jadwal.store');
        Route::get('/jadwal/{id}/edit', [JadwalController::class, 'edit'])->name('guru.jadwal.edit');
        Route::put('/jadwal/{id}', [JadwalController::class, 'update'])->name('guru.jadwal.update');
        Route::delete('/jadwal/{id}', [JadwalController::class, 'destroy'])->name('guru.jadwal.destroy');
        Route::post('/jadwal/store', [JadwalController::class, 'store'])->name('jadwal.store');


        // Laporan
        Route::get('/laporan', [LaporanController::class, 'index'])->name('guru.laporan');
        Route::get('/laporan/generate', [LaporanController::class, 'generate'])->name('guru.laporan.generate');
        Route::post('/laporan/export', [LaporanController::class, 'export'])->name('guru.laporan.export');

        // Pengumuman
        Route::get('/pengumuman', [PengumumanController::class, 'index'])->name('guru.pengumuman');
        Route::get('/pengumuman/create', [PengumumanController::class, 'create'])->name('guru.pengumuman.create');
        Route::post('/pengumuman', [PengumumanController::class, 'store'])->name('guru.pengumuman.store');
        Route::get('/pengumuman/{id}/edit', [PengumumanController::class, 'edit'])->name('guru.pengumuman.edit');
        Route::put('/pengumuman/{id}', [PengumumanController::class, 'update'])->name('guru.pengumuman.update');
        Route::delete('/pengumuman/{id}', [PengumumanController::class, 'destroy'])->name('guru.pengumuman.destroy');

        // Pengaturan
        Route::get('/pengaturan', [PengaturanController::class, 'index'])->name('guru.pengaturan');
        Route::put('/pengaturan', [PengaturanController::class, 'update'])->name('guru.pengaturan.update');
    });
});
